﻿using System;
using System.Data.OleDb;
using System.IO;
using System.Windows.Forms;

namespace Praktika
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox2.UseSystemPasswordChar = true;
            this.AcceptButton = button1;
            this.CancelButton = button2;
        }

        private void Button2_Click(object sender, EventArgs e) => this.Close();

        private string GetConnStr()
        {
            var dbPath = Path.Combine(Application.StartupPath, "Datauser.accdb");
            return $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={dbPath};Persist Security Info=False;";
        }

        private sealed class AuthResult
        {
            public int UserId { get; set; }
            public string Login { get; set; }
            public string RoleName { get; set; } // конечное текстовое имя роли
        }

        private AuthResult Authenticate(string login, string password)
        {
            using (var conn = new OleDbConnection(GetConnStr()))
            {
                conn.Open();

                // 1) Берём пользователя и сырое значение Users.[Role] (может быть текст или Id)
                int userId;
                string loginOut;
                object roleRawObj;

                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "SELECT [ID] AS UserId, [Login], [Role] FROM [Users] WHERE [Login]=? AND [Password]=?";
                    cmd.Parameters.AddWithValue("@p1", login);
                    cmd.Parameters.AddWithValue("@p2", password);

                    using (var rd = cmd.ExecuteReader())
                    {
                        if (rd == null || !rd.Read())
                            return null;

                        userId = Convert.ToInt32(rd["UserId"]);
                        loginOut = rd["Login"].ToString();
                        roleRawObj = rd["Role"];
                    }
                }

                // 2) Превращаем Role в текст
                string roleName = "";
                if (roleRawObj != DBNull.Value && roleRawObj != null)
                {
                    // Может быть числом (Id) или текстом
                    int roleId;
                    var roleStr = Convert.ToString(roleRawObj);
                    if (!string.IsNullOrWhiteSpace(roleStr) && int.TryParse(roleStr, out roleId))
                    {
                        using (var cmd2 = conn.CreateCommand())
                        {
                            cmd2.CommandText = "SELECT [Роль] FROM [Roles] WHERE [ID] = ?";
                            cmd2.Parameters.AddWithValue("@p1", roleId);
                            var name = cmd2.ExecuteScalar();
                            roleName = name == null || name == DBNull.Value ? "" : name.ToString();
                        }
                    }
                    else
                    {
                        roleName = roleStr;
                    }
                }

                return new AuthResult { UserId = userId, Login = loginOut, RoleName = roleName };
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string login = textBox1.Text;
            string password = textBox2.Text;

            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Введите логин и пароль");
                return;
            }

            var auth = Authenticate(login, password);
            if (auth != null)
            {
                var roleCode = NormalizeRole(auth.RoleName); // "admin"/"manager"/"user"
                MessageBox.Show($"Добро пожаловать, {auth.Login}. Ваша роль: {auth.RoleName}");
                var formCars = new Form3(roleCode);
                // Диагностика: покажем полученную роль в заголовке
                formCars.Text += $" (role={roleCode})";
                formCars.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль");
            }
        }

        private string NormalizeRole(string role)
        {
            if (string.IsNullOrWhiteSpace(role)) return "user";
            var r = role.Trim().ToLowerInvariant();
            if (r.Contains("адм") || r == "admin" || r == "administrator") return "admin";
            if (r.Contains("мен") || r == "manager") return "manager";
            return "user";
        }
    }
}