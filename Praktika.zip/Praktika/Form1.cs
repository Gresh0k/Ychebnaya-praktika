﻿using System.Data.OleDb;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics.Eventing.Reader;

namespace Praktika
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string login = textBox1.Text;
            string password = textBox2.Text;

            if (login == "" || password == "")
            {
                MessageBox.Show("Введите логин и пароль");
                return;
            }

            // адаптер
            var adapter = new DataUserDataSetTableAdapters.UsersTableAdapter();
            var usersTable = adapter.GetData();

            // проверка, есть ли такой пользователь
            var foundRows = usersTable
                .Where(u => u.Login == login && u.Password == password);

            if (foundRows.Any())
            {
                var user = foundRows.First();
                MessageBox.Show($"Добро пожаловать, {user.Login}. Ваша роль: {user.Role}");
                Form3 formCars = new Form3();
                formCars.Show();  // Открыть новую форму
                this.Hide();  // Закрыть текущую форму (Form1)
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль");
            }
        }
    }
}
