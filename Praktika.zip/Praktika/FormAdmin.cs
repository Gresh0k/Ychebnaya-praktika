﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Praktika
{
    public partial class FormAdmin : Form
    {
        private readonly string connectionString;
        private TabControl tabControl;
        private Button buttonSaveAll;
        private Button buttonClose;

        private class TableContext
        {
            public DataGridView Grid;
            public DataTable Data;
            public OleDbDataAdapter Adapter;
            public OleDbCommandBuilder Builder;
        }

        private readonly Dictionary<string, TableContext> tables = new Dictionary<string, TableContext>();

        public FormAdmin(string connStr)
        {
            InitializeComponent();   // если есть Designer — он подключится
            this.Controls.Clear();   // очистим форму, чтобы не мешали элементы из дизайнера

            connectionString = connStr;
            InitUi();
            LoadAllTables();
        }

        private void InitUi()
        {
            this.Text = "Админ-панель";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Size = new Size(1000, 650);

            tabControl = new TabControl { Dock = DockStyle.Fill };

            var bottom = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 50,
                BackColor = Color.FromArgb(45, 45, 45)
            };

            buttonSaveAll = new Button
            {
                Text = "Сохранить все",
                BackColor = Color.FromArgb(76, 175, 80),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Size = new Size(130, 30),
                Location = new Point(15, 10)
            };
            buttonSaveAll.Click += ButtonSaveAll_Click;

            buttonClose = new Button
            {
                Text = "Закрыть",
                BackColor = Color.FromArgb(220, 20, 60),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Size = new Size(100, 30),
                Location = new Point(160, 10)
            };
            buttonClose.Click += (s, e) => this.Close();

            bottom.Controls.Add(buttonSaveAll);
            bottom.Controls.Add(buttonClose);

            this.Controls.Add(tabControl);
            this.Controls.Add(bottom);
        }

        private void LoadAllTables()
        {
            try
            {
                using (var conn = new OleDbConnection(connectionString))
                {
                    conn.Open();

                    var schema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                    if (schema == null || schema.Rows.Count == 0)
                    {
                        MessageBox.Show("В базе не найдено пользовательских таблиц.");
                        return;
                    }

                    var tableNames = schema.AsEnumerable()
                        .Select(r => r.Field<string>("TABLE_NAME"))
                        .Where(n =>
                            !string.IsNullOrWhiteSpace(n) &&
                            !n.StartsWith("MSys", StringComparison.OrdinalIgnoreCase) &&
                            !n.StartsWith("USys", StringComparison.OrdinalIgnoreCase))
                        .OrderBy(n => n)
                        .ToList();

                    foreach (var name in tableNames)
                        CreateTableTab(name);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки списка таблиц: " + ex.Message);
            }
        }
        private void CreateTableTab(string tableName)
        {
            var page = new TabPage(tableName);

            var grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                AllowUserToAddRows = true,
                AllowUserToDeleteRows = true,
                BackgroundColor = Color.White
            };

            var ctx = new TableContext { Grid = grid };

            try
            {
                ctx.Adapter = new OleDbDataAdapter($"SELECT * FROM [{tableName}]", connectionString)
                {
                    MissingSchemaAction = MissingSchemaAction.AddWithKey
                };
                ctx.Builder = new OleDbCommandBuilder(ctx.Adapter)
                {
                    QuotePrefix = "[",
                    QuoteSuffix = "]"
                };

                ctx.Data = new DataTable();
                ctx.Adapter.Fill(ctx.Data);
                grid.DataSource = ctx.Data;

                page.Controls.Add(grid);
                tables[tableName] = ctx;
            }
            catch (Exception ex)
            {
                var lbl = new Label
                {
                    Dock = DockStyle.Fill,
                    Text = "Ошибка загрузки: " + ex.Message,
                    ForeColor = Color.Red,
                    TextAlign = ContentAlignment.MiddleCenter
                };
                page.Controls.Add(lbl);
            }

            tabControl.TabPages.Add(page);
        }

        private void ButtonSaveAll_Click(object sender, EventArgs e)
        {
            int total = 0;
            var errors = new List<string>();

            foreach (var kv in tables)
            {
                try
                {
                    var ctx = kv.Value;

                    ctx.Grid.EndEdit();
                    this.Validate();

                    var changes = ctx.Data.GetChanges();
                    if (changes == null) continue;

                    int affected = ctx.Adapter.Update(ctx.Data);
                    ctx.Data.AcceptChanges();
                    total += affected;
                }
                catch (Exception ex)
                {
                    errors.Add($"{kv.Key}: {ex.Message}");
                }
            }

            if (errors.Count > 0)
                MessageBox.Show("Сохранено строк: " + total + "\nОшибки:\n" + string.Join("\n", errors));
            else
                MessageBox.Show("Сохранено строк: " + total);
        }
    }
}