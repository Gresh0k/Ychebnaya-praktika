﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Praktika
{
    public partial class Form3 : Form
    {
        private readonly string roleCode; // "user" | "manager" | "admin"

        private OleDbConnection connection;
        private DataTable carsTable;
        private OleDbDataAdapter carsAdapter;
        private OleDbCommandBuilder carsCmdBuilder;

        private Button buttonSaveCars;     // кнопка "Сохранить" для manager/admin
        private Button buttonAdminPanel;   // кнопка "Админ-панель" для admin

        // Пустой конструктор оставляем для дизайнера
        public Form3() : this("user") { }

        public Form3(string roleCode)
        {
            InitializeComponent();

            this.roleCode = (roleCode ?? "user").ToLowerInvariant();
            var dbPath = Path.Combine(Application.StartupPath, "D:\\УЧЕБА\\5 семестр\\Учебная практика\\Praktika\\Praktika\\Datauser.accdb");
            connection = new OleDbConnection($@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={dbPath};Persist Security Info=False;");

            // Диагностика: покажем путь и роль в заголовке
            this.Text = $"Каталог автомобилей — {dbPath} — роль={roleCode}";

            // Дополнительные элементы интерфейса по ролям
            CreateRoleButtons();
            ApplyPermissions();

            // Привяжем обработчик выбора строки (для labelSelected)
            this.dataGridViewCars.SelectionChanged += dataGridViewCars_SelectionChanged;

            // Загружаем данные
            LoadCars();
        }

        private void CreateRoleButtons()
        {
            // Кнопка "Сохранить" — для Manager/Admin
            buttonSaveCars = new Button
            {
                Text = "Сохранить",
                BackColor = Color.FromArgb(76, 175, 80),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Size = new Size(110, 30),
                Visible = false // покажем ниже в ApplyPermissions
            };
            buttonSaveCars.Click += buttonSaveCars_Click;

            // Кнопка "Админ-панель" — только для Admin
            buttonAdminPanel = new Button
            {
                Text = "Админ-панель",
                BackColor = Color.FromArgb(120, 120, 120),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Size = new Size(120, 30),
                Visible = false
            };
            buttonAdminPanel.Click += buttonAdminPanel_Click;

            // Располагаем справа от "Обновить"
            int nextX = buttonRefresh.Right + 10;
            buttonSaveCars.Location = new Point(nextX, buttonRefresh.Top);
            nextX = buttonSaveCars.Right + 10;
            buttonAdminPanel.Location = new Point(nextX, buttonRefresh.Top);

            // Добавляем на нижнюю панель
            panelBottom.Controls.Add(buttonSaveCars);
            panelBottom.Controls.Add(buttonAdminPanel);
        }

        private void ApplyPermissions()
        {
            bool isAdmin = roleCode == "admin";
            bool isManager = roleCode == "manager";

            if (!(isAdmin || isManager))
            {
                // Пользователь — только просмотр
                dataGridViewCars.ReadOnly = true;
                dataGridViewCars.AllowUserToAddRows = false;
                dataGridViewCars.AllowUserToDeleteRows = false;

                buttonSaveCars.Visible = false;
                buttonAdminPanel.Visible = false;
            }
            else
            {
                // Менеджер и Админ — могут редактировать Cars
                dataGridViewCars.ReadOnly = false;
                dataGridViewCars.AllowUserToAddRows = true;
                dataGridViewCars.AllowUserToDeleteRows = true;

                buttonSaveCars.Visible = true;
                buttonAdminPanel.Visible = isAdmin; // панель только для админа
            }
        }

        private void LoadCars()
        {
            try
            {
                connection.Open();

                string query = "SELECT * FROM Cars";
                carsAdapter = new OleDbDataAdapter(query, connection)
                {
                    MissingSchemaAction = MissingSchemaAction.AddWithKey
                };
                carsCmdBuilder = new OleDbCommandBuilder(carsAdapter)
                {
                    QuotePrefix = "[",
                    QuoteSuffix = "]"
                };

                carsTable = new DataTable();
                carsAdapter.Fill(carsTable);

                // Привязываем DefaultView — удобно для фильтра
                dataGridViewCars.DataSource = carsTable.DefaultView;

                // При первом показе сбросим фильтр к "Все", если не выбран
                if (comboBoxClassFilter.SelectedIndex < 0)
                    comboBoxClassFilter.SelectedIndex = 0;

                // Применим фильтр к текущему значению
                FilterCars();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void buttonSaveCars_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();

                // Зафиксировать все редактирования в гриде и в текущей записи
                dataGridViewCars.CommitEdit(DataGridViewDataErrorContexts.Commit);
                dataGridViewCars.EndEdit();
                var cm = (CurrencyManager)this.BindingContext[carsTable.DefaultView];
                cm.EndCurrentEdit();

                // На всякий случай — если команды не сгенерированы (нет PK), создадим билдер
                if (carsAdapter.UpdateCommand == null || carsAdapter.InsertCommand == null || carsAdapter.DeleteCommand == null)
                {
                    carsCmdBuilder = new OleDbCommandBuilder(carsAdapter) { QuotePrefix = "[", QuoteSuffix = "]" };
                }

                var changes = carsTable.GetChanges(DataRowState.Added | DataRowState.Modified | DataRowState.Deleted);
                if (changes == null)
                {
                    MessageBox.Show("Нет изменений для сохранения.");
                    return;
                }

                int affected = carsAdapter.Update(carsTable); // Update ДО AcceptChanges
                carsTable.AcceptChanges();

                MessageBox.Show($"Сохранено строк: {affected}");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения: " + ex.Message +
                    "\nПроверьте первичный ключ ID в Cars и права на запись в файл БД.");
            }
        }

        private void buttonAdminPanel_Click(object sender, EventArgs e)
        {
            try
            {
                using (var admin = new FormAdmin(connection.ConnectionString))
                {
                    admin.ShowDialog(this);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось открыть админ-панель: " + ex.Message);
            }
        }

        private void dataGridViewCars_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (dataGridViewCars.CurrentRow?.DataBoundItem is DataRowView drv)
                {
                    string brand = SafeGet(drv, "Марка");
                    string model = SafeGet(drv, "Модель");
                    string klass = SafeGet(drv, "Класс");
                    labelSelected.Text = $"Выбран: {brand} {model} ({klass})";
                }
                else
                {
                    labelSelected.Text = "Выберите автомобиль...";
                }
            }
            catch
            {
                labelSelected.Text = "Выберите автомобиль...";
            }
        }

        private string SafeGet(DataRowView drv, string columnName)
        {
            return drv.Row.Table.Columns.Contains(columnName) ? (drv[columnName]?.ToString() ?? "") : "";
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            LoadCars();
        }

        private void comboBoxClassFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            FilterCars();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void FilterCars()
        {
            if (carsTable == null) return;

            string selectedClass = comboBoxClassFilter.Text;
            if (!string.IsNullOrEmpty(selectedClass) && selectedClass != "Все")
            {
                var val = selectedClass.Replace("'", "''");
                carsTable.DefaultView.RowFilter = $"[Класс] = '{val}'";
            }
            else
            {
                carsTable.DefaultView.RowFilter = "";
                // Сообщение при "Все" убрано
            }
        }
    }
}