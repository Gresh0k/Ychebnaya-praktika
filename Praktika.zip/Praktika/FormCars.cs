﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Praktika
{
    public partial class Form3 : Form
    {
        private OleDbConnection connection;
        private DataTable carsTable;

        public Form3()
        {
            InitializeComponent();
            connection = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Datauser.accdb;");
            LoadCars();
        }
        private void LoadCars()
        {
            comboBoxClassFilter.SelectedIndex = 0; // "Все"
            try
            {
                connection.Open();
                string query = "SELECT * FROM Cars";
                OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection);
                carsTable = new DataTable();
                adapter.Fill(carsTable);
                dataGridViewCars.DataSource = carsTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            LoadCars();
        }

        private void comboBoxClassFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            FilterCars();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void FilterCars()
        {
            if (carsTable == null) return;

            string selectedClass = comboBoxClassFilter.Text;
            DataView view = new DataView(carsTable);

            if (selectedClass != "Все" && !string.IsNullOrEmpty(selectedClass))
            {
                // Оборачиваем имя столбца в квадратные скобки
                view.RowFilter = $"[Класс] = '{selectedClass}'";
            }
            else
            {
                view.RowFilter = "";
                MessageBox.Show($"Фильтр: {selectedClass}");

            }

            dataGridViewCars.DataSource = view;
        }

    }
}